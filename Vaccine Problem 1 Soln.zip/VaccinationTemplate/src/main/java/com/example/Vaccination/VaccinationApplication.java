package com.example.Vaccination;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class VaccinationApplication {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome to the Vaccination Application");

		User user = null;

		while (true) {
			System.out.println("Please choose your vaccine preference: \n1.Covid \n2.Polio \n3.Typhoid");
			int vaccineChoice = sc.nextInt();
            sc.nextLine();

			String vaccineType = "";

			switch (vaccineChoice) {
				case 1 -> vaccineType = "Covid";
				case 2 -> vaccineType = "Polio";
				case 3 -> vaccineType = "Typhoid";
				default -> {
					System.out.println("Invalid choice");
					return;
				}
			}

			System.out.println("Whom do you want to vaccinate: \n1.Father \n2.Mother \n3.Self \n4.Spouse \n5.Exit");
			int userChoice = sc.nextInt();
			String userType = "";

			switch (userChoice) {
				case 1 -> userType = "father";
				case 2 -> userType = "mother";
				case 3 -> userType = "self";
				case 4 -> userType = "spouse";
				default -> {
					System.out.println("Invalid choice");
					return;
				}
			}


			String bean = userType + vaccineType;
			user = (User) context.getBean(bean);


			if(user.IsVaccinated()) {
				System.out.println("User is already vaccinated.");
			}
			else {
			System.out.println("Please enter " + userType + " details:");
			System.out.print("Name: ");
			String name = sc.nextLine();
			sc.nextLine();

			System.out.print("Age: ");
			int age = sc.nextInt();
			sc.nextLine();

			System.out.print("Appointment Date(YY-MM-DD): ");
			String date = sc.nextLine();

			System.out.print("Appointment Time(HH:MM AM/PM): ");
			String time = sc.nextLine();

			System.out.print("Appointment location: ");
			String location = sc.nextLine();


			TimeAndLocation timeAndLocation = (TimeAndLocation) context.getBean("timeAndLocation");
			timeAndLocation.setDetails(time, location, date);

			user.setUserDetails(name, age, timeAndLocation);
			user.setAppointment();
			}

		System.out.println("Do you want to register for someone else? \n1.Yes \n2.No");
		int choice = sc.nextInt();
		if(choice == 2) {
			break;
		}
		}
		/*
		 * You need to complete this application as mentioned in the problem
		 * statement build your own logic and perform the following tasks.
		 * 
		 * Tasks:
		 * 1. Fetch context from ApplicationContext.xml and initiate Scanner.
		 * 2. Fetch vaccine and User type choice.
		 * 3. Get the required bean from context.
		 * 4. Get the appointment details form user
		 * 5. Display the appointment details
		 * 6. Run the loop again to book for another user or else exit.
		 */

	}
}