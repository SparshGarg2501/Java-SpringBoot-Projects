package com.codingNinjas.carDealership;

public class HeavyTyre implements Tyre {

	@Override
	public String getTyreInfo() {
		// TODO Auto-generated method stub
		return "with Heavy Tyres";
	}

}
