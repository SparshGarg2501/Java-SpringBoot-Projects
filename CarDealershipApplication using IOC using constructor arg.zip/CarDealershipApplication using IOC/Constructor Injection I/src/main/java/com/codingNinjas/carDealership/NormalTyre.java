package com.codingNinjas.carDealership;

public class NormalTyre implements Tyre {

	@Override
	public String getTyreInfo() {
		// TODO Auto-generated method stub
		return "with Normal Tyres";
	}

}
