package com.codingNinjas.carDealership;

public class SportsTyre implements Tyre {

	@Override
	public String getTyreInfo() {
		// TODO Auto-generated method stub
		return "with Sports Tyre";
	}

}
