package com.example.CustomerServicedemo;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.Customers.CustomerCare;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerServicedemoApplication {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Welcome to Customer Care Application ");
		System.out.println("Please enter your name: ");
		String customerName = scanner.nextLine();
		CustomerCare customerCare = null;
		String service = " ";
		
		System.out.println("Thanks for reaching us "+ customerName);
		System.out.println("Please select a department to connect to:");
		System.out.println("1. Payment Department");
		System.out.println("2. Query Department");
		System.out.println("3. Sales Department");
		System.out.println("0. Exit");
		
		int choice = scanner.nextInt();
		scanner.nextLine();
		
		if(choice>=0 && choice<4) {
			switch(choice) {
			
			
			case 1:
				service = "paymentDepartment";
				break;
				
			case 2:
				service = "queryDepartment";
				break;
				
			case 3:
				service = "salesDepartment";
				break;
				
			default:
				System.out.println("You have exited the application:");
			}
		}
		
		customerCare = (CustomerCare) context.getBean(service);
		customerCare.setCustomerName(customerName);
		customerCare.getService();
		String issue = scanner.nextLine();
		customerCare.setProblem(issue);
		customerCare.getProblem();
		/*
		You need to complete this application as mentioned in the problem 
		statement build your own logic and perform the following tasks.

			 Tasks:
		 *  1. Load the beans from ApplicationContext.xml
		 *  2. Display all the departments available and get the input from user.
		 *  3. Get the message from user and store it into the respective department.
		 *  
		 */
	}
}
