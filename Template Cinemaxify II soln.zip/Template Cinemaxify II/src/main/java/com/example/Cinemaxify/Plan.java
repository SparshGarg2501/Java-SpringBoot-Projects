package com.example.Cinemaxify;

/** The Plan interface features a single method,getPlanName(), which retrieves the plan name. **/
public interface Plan {

    /** The method retrieves the plan name. **/
    String getPlanName();
}
