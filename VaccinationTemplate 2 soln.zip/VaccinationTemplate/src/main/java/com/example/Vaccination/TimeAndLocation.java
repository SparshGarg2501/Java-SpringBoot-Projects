package com.example.Vaccination;

/**
 * TimeAndLocation class is used to store and manage appointment details.
 * It includes timeSlot, location, and date information.
 */
public class TimeAndLocation {

    // Common attributes
    private String timeSlot;
    private String location;
    private String date;

    // Method to set details
//    public void setDetails(String timeSlot, String location, String date) {
//        this.timeSlot = timeSlot;
//        this.location = location;
//        this.date = date;
//    }
//    
    
//
//   // public String getTimeSlot() {
//		return timeSlot;
//	}



	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public void setDate(String date) {
		this.date = date;
	}



	// Method to get formatted details
    public String getDetails() {
        return timeSlot + " at " + location + " on " + date;
    }

    // Optional: Getter methods if needed by other classes

//    public String getTime() {
//        return timeSlot;
//    }
//
//    public String getLocation() {
//        return location;
//    }
//
//    public String getDate() {
//        return date;
//    }
}