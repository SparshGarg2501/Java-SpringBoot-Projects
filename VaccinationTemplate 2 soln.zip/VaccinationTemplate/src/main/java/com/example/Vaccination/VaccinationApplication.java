package com.example.Vaccination;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@SpringBootApplication
public class VaccinationApplication {

    public static void main(String[] args) {

        /*
		You need to complete this application as mentioned in the problem 
		statement build your own logic and perform the following tasks.

		 Tasks:
		1. Fetch context from ApplicationContext.xml and initiate Scanner.
		2. Fetch vaccine and User type choice.
		3. Get the required bean from context.
		4. Get the appointment details form user
		5. Display the appointment details
		6. Run the loop again to book for another user or else exit.
		 */
    	
    	
    	 // 1. Fetch context from appcontext.xml and initiate Scanner
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
        Scanner sc = new Scanner(System.in);

        boolean continueBooking = true;

        while (continueBooking) {
            // 2. Fetch vaccine and user type choice
            System.out.println("Welcome to the Vaccination Application ");
            System.out.println("Please choose your vaccine preference: \n1. Covid \n2.Polio \n3.Typhoid");
            
            int vaccineChoice = sc.nextInt();
            String vaccineType = "";
            switch(vaccineChoice) {
            case 1->vaccineType  = "Covid";
            
            case 2-> vaccineType = "Polio";
            
            case 3-> vaccineType = "Typhoid";
            
            default->{ System.out.println("Invalid choice..");
            return;
            }
            }

            System.out.println("Whom do you want to vaccinate: \n1. Father \n2.Mother \n3.Self \n4.Spouse \n5.Exit");
          
            int userType = sc.nextInt();
            String userChoose = "";
            switch(userType)
            {
            case 1-> userChoose = "Father";
            case 2-> userChoose = "Mother";
            case 3-> userChoose = "Self";
            case 4-> userChoose = "Spouse";
            case 5-> userChoose = "Exit";
            default->{
            	System.out.println("Invalid choice..");
            	return;
            }
            }

            // Bean ID is camelCase combination: userType + VaccineName
            String bean = userChoose.toLowerCase()+ vaccineType;
            User user = (User) context.getBean(bean);


            // 3. Get the required user bean from context
            
                if(user.IsVaccinated()) {
                	System.out.println("User is already vaccinated");
                	continue;	
                }
                System.out.println("Please enter" +userChoose+"details");
                System.out.println("Name");
                 
                String name = sc.next();

                System.out.print("Enter Age: ");
                int age = sc.nextInt();

                System.out.print("Enter Time Slot (e.g., 12:00 PM): ");
                String time = sc.next();

                System.out.print("Enter Location: ");
                String location = sc.next();

                System.out.print("Enter Date (yyyy-mm-dd): ");
                String date = sc.next();

                // Set details
                TimeAndLocation timeAndLocation = new TimeAndLocation();
                timeAndLocation.setDate(date);
                timeAndLocation.setTimeSlot(time);
                timeAndLocation.setLocation(location);
                
                user.setUserDetails(name, age, timeAndLocation);
                user.setAppointment();

                System.out.println("Do you went to register for someone Else \n1. Yes \n2. No");

                int choice = sc.nextInt();

                if(choice != 1 ) {

                break;
                }
        }
    }
}
    