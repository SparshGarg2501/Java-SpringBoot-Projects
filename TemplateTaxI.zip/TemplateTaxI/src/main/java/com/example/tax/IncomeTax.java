package com.example.tax;

public class IncomeTax implements Tax {
double taxableAmount;
double taxAmount;
boolean isTaxPayed;


public IncomeTax(){
	this.taxAmount = 0.0;
	this.isTaxPayed = false;
}

	@Override
	public void setTaxableAmount(int amount) {
		// TODO Auto-generated method stub
		this.taxableAmount = amount;
	}

	@Override
	public void calculateTaxAmount() {
		// TODO Auto-generated method stub 
		// this.taxable amount = am*0.05;
		double am = this.taxableAmount;
		
		if(am>0 && am<=300000.0){
		this.taxAmount=0.0;
		}
		else if(am>300000.0 && am<=600000.0){
		this.taxAmount=am*0.05;

		}
		else if(am>600000.0 && am<=900000.0){
		this.taxAmount=am*0.1;

		}

		else if(am>900000.0 && am<=1200000.0){

		this.taxAmount=am*0.15;

		}

		else if(am>1200000.0 && am<=1500000.0){

		this.taxAmount=am*0.2;

		}

		else if(am>1500000.0){

		this.taxAmount=am*0.3;

		}
	}

	@Override
	public double getTaxAmount() {
		// TODO Auto-generated method stub
		return this.taxAmount;
	}

	@Override
	public String getTaxType() {
		// TODO Auto-generated method stub
		return "income";//property
	}

	@Override
	public boolean isTaxPayed() {
		// TODO Auto-generated method stub
		return this.isTaxPayed;
	}

	@Override
	public void payTax() {
		// TODO Auto-generated method stub
		this.isTaxPayed = true;
		System.out.println("Hi! Your income tax is paid");//property
		
	}
    /*
    1. Create the following attributes.
        a. taxableAmount (double)
        b. taxAmount (double)
        c. isTaxPayed (boolean)
    2. Make this class an implementation of Tax interface and override the interface methods.
    3. Using constructor initialize the isTaxPayed boolean false.
     */
	
	
	
	
	
}
