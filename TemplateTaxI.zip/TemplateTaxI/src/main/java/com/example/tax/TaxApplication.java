package com.example.tax;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {
		// Take ClassPathXmlApplicationContext from applicationContext.xml file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Scanner s = new Scanner(System.in);
		System.out.println("Select the choice:");
		String ch= s.nextLine();
		switch(ch){

		 

		case "income":

		Tax inc=(Tax) context.getBean("incomeTax");

		break;

		 

		case "property":

		Tax prop=(Tax) context.getBean("propertyTax");

		break;

		 

		default:

		System.out.println("Invalid type try again");

		break;

		}

		 

		Tax in=new IncomeTax();

		//Tax pr=new PropertyTax();

		in.setTaxableAmount(900000);

		in.calculateTaxAmount();

		// pr.calculateTaxAmount();

		System.out.println("Tax amount="+in.getTaxAmount());

		// System.out.println("Tax amount="+pr.getTaxAmount());






		
		
		
	}
	

}
