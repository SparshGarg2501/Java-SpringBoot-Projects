package com.example.tax;

public class PropertyTax implements Tax {
    /*
    1. Create the following attributes.
        a. taxableAmount (double)
        b. taxAmount (double)
        c. isTaxPayed (boolean)
    2. Make this class an implementation of Tax interface and override the interface methods.
    3. Using constructor initialize the isTaxPayed boolean false.
     */
	double taxableAmount;
	double taxAmount;
	boolean isTaxPayed;


	public PropertyTax(){
		this.taxAmount = 0.0;
		this.isTaxPayed = false;
	}

		@Override
		public void setTaxableAmount(int amount) {
			// TODO Auto-generated method stub
			this.taxableAmount = amount;
		}

		@Override
		public void calculateTaxAmount() {
			// TODO Auto-generated method stub 
			
			double am = this.taxableAmount;
			 this.taxAmount = am*0.05;
			
		}

		@Override
		public double getTaxAmount() {
			// TODO Auto-generated method stub
			return this.taxAmount;
		}

		@Override
		public String getTaxType() {
			// TODO Auto-generated method stub
			return "property";//property
		}

		@Override
		public boolean isTaxPayed() {
			// TODO Auto-generated method stub
			return this.isTaxPayed;
		}

		@Override
		public void payTax() {
			// TODO Auto-generated method stub
			this.isTaxPayed = true;
			System.out.println("Hi! Your property tax is paid");//property
			
		}
}
